import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    final static int ServerPort = 6666;

    public static void main(String[] args) throws IOException {
        Scanner scn = new Scanner(System.in);
        // getting localhost ip
        InetAddress ip = InetAddress.getByName("178.128.194.107"); // 178.128.194.107 //localhost

        // establish the connection
        Socket s = new Socket(ip, ServerPort);

        // obtaining input and out streams
        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());

        System.out.println("Connection established to server... use correct protocol! --> CONNECT#");

        // sendMessage thread
        Thread sendMessage = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    // read the message to deliver.
                    String msg = scn.nextLine();

                    try {
                        // write on the output stream
                        dos.writeUTF(msg);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });


        // readMessage thread
        Thread readMessage = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        // read the message sent to this client
                        String msg = dis.readUTF();
                        if (msg.equalsIgnoreCase("CLOSE#0")){
                            System.out.println("Shutting Down Client - Bye!....");
                            dis.close();
                            dos.close();
                            s.close();
                            System.exit(0);
                        } else if (msg.equalsIgnoreCase("CLOSE#1")) {
                            System.out.println("illegal input received");
                            dis.close();
                            dos.close();
                            s.close();
                            System.exit(0);
                        } else if (msg.equalsIgnoreCase("CLOSE#2")) {
                            System.out.println("User not found / already logged in");
                            dis.close();
                            dos.close();
                            s.close();
                            System.exit(0);
                        }else {
                            System.out.println(msg);
                        }
                    } catch (IOException e) {

                        e.printStackTrace();
                    }
                }
            }
        });
        sendMessage.start();
        readMessage.start();
    }
}